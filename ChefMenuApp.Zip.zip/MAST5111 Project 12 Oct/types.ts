
export type MenuItem = {
    id: string;
    name: string;
    description: string;
    course: string;
    price: number;
};

export type RootStackParamList = {
    Home: undefined;
    AddMenuItem: undefined;
};